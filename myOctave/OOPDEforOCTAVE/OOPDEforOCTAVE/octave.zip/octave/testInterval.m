try
  I = Interval([-1 2],0.1);
catch ME
  class(ME)
  rethrow(ME)
end

