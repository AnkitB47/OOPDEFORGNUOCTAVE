classdef PolygonGeometry < grid2D
    methods
        function obj = PolygonGeometry(polygon,h)
            obj.polygonGeometry(polygon,h);
        end
    end
end

